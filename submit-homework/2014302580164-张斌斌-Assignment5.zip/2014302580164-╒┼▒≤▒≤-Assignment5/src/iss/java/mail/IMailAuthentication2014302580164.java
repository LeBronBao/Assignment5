package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

/**
 * 服务器邮箱登陆验证 <p>
 * 
 * @author 张斌
 * @date 2015年11月24日 
 */
public class IMailAuthentication2014302580164 extends Authenticator{
	/**
	 * 用户名
	 */
	private String username;
	/**
	 * 密码
	 */
	private String password;
	
	/**
	 *
	 * 初始化邮箱和密码 <p> <br>
	 * @param sUserName
	 * @param sPassword
	 * 
	 */
	public IMailAuthentication2014302580164(String sUsername,String sPassword){
		username = sUsername;
		password = sPassword;
	}
	
	/**
	 * username的get方法
	 * @return username
	 */
	public String getUsername (){
		return username;
	}
	
	/**
	 * username的set方法
	 * @param username
	 */
	public void setUsername(String username){
		this.username = username;
	}
	
	/**
	 * password的get方法
	 * @return password
	 */
	public String getPassword(){
		return password;
	}
	
	/**
	 * password的set方法
	 * @param password
	 */
	public void setPassword(String password){
		this.password = password;
	}
	
	/** 
	 * 构建一个新的PasswordAuthetication对象并返回
	 * @override
	 * @see javax.mail.Authenticator#getPasswordAuthentication()
	 * @return new PasswordAuthetication
	 */
	@Override
	protected PasswordAuthentication getPasswordAuthentication(){
		return new PasswordAuthentication(username,password);
	}
	
}

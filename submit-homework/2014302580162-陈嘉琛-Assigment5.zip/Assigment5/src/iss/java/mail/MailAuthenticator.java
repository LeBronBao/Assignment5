package iss.java.mail;
/**
 * @author Aron
 */
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class MailAuthenticator extends Authenticator {
	/**
	 * �˺�����
	 * @author Aron
	 */
	private String username;
	private String password;
	/**
	 * ��ʼ��
	 */
	public MailAuthenticator(String username,String password){
		this.username = username;
		this.password = password;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public String getPassword() {
		return password;
	}
	@Override
	protected PasswordAuthentication getPasswordAuthentication(){
		return new PasswordAuthentication(username,password);
	}
}

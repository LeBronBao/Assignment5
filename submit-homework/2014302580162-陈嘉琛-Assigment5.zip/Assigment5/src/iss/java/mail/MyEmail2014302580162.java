package iss.java.mail;
/**
 * ʵ�ֽӿ�IMailService
 * @author Aron 
 */
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
/**
 * @author Aron
 */

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class MyEmail2014302580162 implements IMailService{

	private final transient Properties props =System.getProperties();
	private final transient Properties receiverprops = System.getProperties();
	/**
	 * ��½��Ϣ
	 */
	private transient MailAuthenticator authenticator;

	/**
	 * ����
	 */
	private transient Session session;
	
	/**
	 * �����ʼ��ķ�����IP
	 */
	private String mailServerHost = "smtp.163.com";

	private Folder folder;
	
	/**
	 * ��ʼ����������
	 */
	@Override
	public void connect() throws MessagingException {
		/**
		 * ������
		 * ��ʼ��
		 */
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.host",mailServerHost);
		
		
		
		/**
		 * �ռ���
		 */
		receiverprops.put("mail.store.protocol", "pop3");
		receiverprops.put("mail.pop3.host", "pop3.163.com");
		
		authenticator = new MailAuthenticator("15927046338@163.com","tvcteowoialnifua");
		session= Session.getInstance(props, authenticator);
	}
/**
 * �����ʼ�
 * @author Aron
 */
	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		final MimeMessage message = new MimeMessage(session);
		message.setFrom(new InternetAddress(authenticator.getUsername()));
		message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
		message.setSubject(subject);
		message.setContent(content.toString(),"text/html;charset=utf-8");
		Transport.send(message);
	}
/**
 * �ж��Ƿ������ʼ�
 * @author Aron
 */
	@Override
	public boolean listen() throws MessagingException {
		Store store = session.getStore();
		store.connect();
		folder = store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		
		int messagecount = folder.getUnreadMessageCount();
		if(messagecount>0){
			return true;
			}
		return false;
	}
/**
 * ���ռ�������ʼ����ݶ�ȡ����
 * @author Aron
 */
	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		int total = folder.getMessageCount();
		Message[] messages = folder.getMessages(1, total);
		int count = messages.length;
		List<String> content = new ArrayList<String>();
		for(int i=0;i<count;i++){
			String msubject = messages[i].getSubject();
			String mfrom = (messages[i].getFrom()[0]).toString();
			String mcontent = messages[i].toString();
			content.add("��"+(i+1)+"���ʼ�������"+msubject+"\r\n");
			content.add("��"+(i+1)+"���ʼ��ķ�����ַ"+mfrom+"\r\n");
			content.add(mcontent+"\r\n");
		}
		return content.toString();
	}

}

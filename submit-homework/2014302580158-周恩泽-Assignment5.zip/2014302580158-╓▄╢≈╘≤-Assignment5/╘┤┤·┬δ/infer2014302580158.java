package iss.java.mail;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

/**
 * IMailService.java中接口的实现
 */
public class infer2014302580158 implements IMailService {
    /**
     * 生成协议对象
     */
    private final transient Properties props = System.getProperties();

    /**
     * 生成一个用户对象,对用户的帐号与密码进行验证
     */

    private transient AuthenticTest authenticator;

    /**
     *获取邮箱session
     */

    private transient Session session;

    @Override
    public void connect() throws MessagingException {
        // 初始化props
        props.put("mail.store.protocol", "imap");
        props.put("mail.imap.host", "imap.163.com");

        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.163.com");

        // 验证
        authenticator = new AuthenticTest("m13163242400_1@163.com","dyqfcknddgzlpggj");

        // 创建session
        session = Session.getInstance(props, authenticator);

    }

    @Override
    public void send(String recipient, String subject, Object content) throws MessagingException {

        // 创建mime类型邮件
        final MimeMessage message = new MimeMessage(session);
        // 设置发信人
        message.setFrom(new InternetAddress(authenticator.getUsername()));
        // 设置收件人
        message.setRecipient(MimeMessage.RecipientType.TO, new InternetAddress(recipient));
        // 设置主题
        message.setSubject(subject);
        // 设置邮件内容
        message.setContent(content.toString(), "text/html;charset=utf-8");
        // 发送
        Transport.send(message);

    }

    @Override
    public boolean listen() throws MessagingException {

        Store store = session.getStore();
        store.connect();
        Folder folder = store.getFolder("INBOX");
        folder.open(Folder.READ_ONLY);
        int num = folder.getUnreadMessageCount();
        if (num==0){
            System.out.println("No unread mail");
            return false;
        }
        else {
            System.out.println("You hava " + num + " unread mails");
            return true;
        }
        /*Message[] messages = folder.getMessages(1,2);
        int mailCounts = messages.length;

        String from = (messages[mailCounts-1].getFrom()[0]).toString();
        folder.close(false);
        store.close();
        if (from.equals("issjava2015@163.com")){
           return true;}//System.out.println(newCount);
        else {
            return false;}*/

    }

    @Override
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException, InterruptedException {


        Store store = session.getStore();
        store.connect();

        // 获得邮箱内的邮件夹Folder对象，以"只读"打开
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);

        Message[] messages = folder.getMessages();

        int mailCounts =  folder.getUnreadMessageCount();
        System.out.println(mailCounts );
        String subjects = messages[mailCounts-1].getSubject();
        if (subjects.equals(subject)) {

            String from = (messages[mailCounts - 1].getFrom()[0]).toString();

            System.out.println("自动回复的邮件的主题：" + subject);
            System.out.println("自动回复的邮件的主题：" + from);

            System.out.println("是否打开该邮件(yes/no)?：");

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            if ("yes".equalsIgnoreCase(input)) {
                // 直接输出到控制台中
                messages[mailCounts - 1].writeTo(System.out);
            }
        }
   /*for(int j=0;j<mailCounts ;j++) {
    String subjects = messages[j].getSubject();
    for (int i = 0; i < mailCounts; i++) {
        System.out.println(subjects);
        System.out.println(subject);
        System.out.println(subjects.equals(subject));
        if (subjects.equals(subject)) {

            String from = (messages[i].getFrom()[i]).toString();

            System.out.println("自动回复的邮件的主题：" + subject);
            System.out.println("自动回复的邮件的主题：" + from);

            System.out.println("是否打开该邮件(yes/no)?：");

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            if ("yes".equalsIgnoreCase(input)) {
                // 直接输出到控制台中
                messages[mailCounts - 1].writeTo(System.out);
            }
        }
    }
}*/
        folder.close(false);
        store.close();
        return null;
    }
}

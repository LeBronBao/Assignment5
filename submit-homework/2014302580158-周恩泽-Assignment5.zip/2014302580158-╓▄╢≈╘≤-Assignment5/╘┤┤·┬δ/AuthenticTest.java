package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

/**
 * 用于对客户的邮箱帐户与密码进行验证
 */
public class AuthenticTest extends Authenticator {
    /**
     * 客户帐户名
     */
    private String name;
    /**
     * 客户帐户密码
     */
    private String password;

    public AuthenticTest (String name, String password) {
        this.name = name;
        this.password = password;
    }

    String getPassword() {
        return password;
    }

    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(name, password);
    }

    String getUsername() {
        return name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String name) {
        this.name = name;
    }
}
